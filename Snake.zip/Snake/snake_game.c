#include <stdio.h> // стандартный ввод-вывод
#include <stdlib.h> // для system и malloc
#include <termios.h> // для getch()
#include <pthread.h> // потоки
#include <unistd.h> // usleep()
#include <stdbool.h> // для булевых переменных

#define X_MAX 100 // ширина поля
#define Y_MAX 37 // высота поля
#define X_START 50 // начальные координаты головы
#define Y_START 6
#define SPEED_MS 200000 // скорость обновления карты

typedef struct sn_node{ // кусочек змеи
    int x;
    int y;
    struct sn_node* next;
    struct sn_node* prev;
}snake_node;

typedef struct eat{ // яблоко
    int x;
    int y;
}apple_coord;


char getch() { // the best func in world!!!
    char buf = 0;
    struct termios old = { 0 };
    fflush(stdout);
    if (tcgetattr(0, &old) < 0) perror("tcsetattr()");
    old.c_lflag    &= ~ICANON;   // local modes = Non Canonical mode
    old.c_lflag    &= ~ECHO;     // local modes = Disable echo. 
    old.c_cc[VMIN]  = 1;         // control chars (MIN value) = 1
    old.c_cc[VTIME] = 0;         // control chars (TIME value) = 0 (No time)
    if (tcsetattr(0, TCSANOW, &old) < 0) perror("tcsetattr ICANON");
    if (read(0, &buf, 1) < 0) perror("read()");
    old.c_lflag    |= ICANON;    // local modes = Canonical mode
    old.c_lflag    |= ECHO;      // local modes = Enable echo. 
    if (tcsetattr(0, TCSADRAIN, &old) < 0) perror ("tcsetattr ~ICANON");
    return buf;
 }




snake_node* create_node(int x, int y){ // создаёт узел змеи с координатами x y
    snake_node* new = (snake_node*)malloc(sizeof(snake_node));
    new->x = x;
    new->y = y;
    new->prev = new->next = NULL;
    return new;
}

char move_head; // Символ, который определяет направление движения головы
char map[Y_MAX][X_MAX]; // карта
int x=X_START,y=Y_START; // стартовые позиции головы
int last_move; // стороны света
apple_coord apple; // яблоко(его координаты)
int eateen_apple=0; // счётчик съеденых яблок
int speed = SPEED_MS;

snake_node* get_tail(snake_node* snake){ // получить координаты хвоста
    if((snake->prev) == NULL) return snake;
    else return get_tail(snake->prev);
}

snake_node* get_head(snake_node* snake){ // получить координаты головы
    if((snake->next) == NULL) return snake;
    else return get_head(snake->next);
}

void push_end(snake_node* snake, int x, int y){ // добавить узел с координатами x y в конец списка - начало змеи
    snake_node* prev_new_head = get_head(snake);
    snake_node* future_head = create_node(x, y);
    future_head->prev=prev_new_head;
    future_head->next = NULL;
    prev_new_head->next = future_head;

}
snake_node* rm_tail(snake_node* snake){ // удаление хвоста
    snake_node* new_tail = snake->next;
    new_tail->prev = NULL;
    free(snake);
    return new_tail;
}

int fill_map(snake_node* snake){ // заполнение змейкой подготовленной карты
    if(snake->next == NULL){ // если нашли голову, то меняем её скин и проверяем, не уперлась ли она в тело
        if((map[snake->y][snake->x] == '#')||(map[snake->y][snake->x] == '@')) return 1;
        map[snake->y][snake->x] = '@';
    }
    else if(snake->prev == NULL){ // скин хвоста
        map[snake->y][snake->x] = 'O';
    }
    else map[snake->y][snake->x] = '#'; // скин тела
    if(snake->next == NULL) return 0;
    else fill_map(snake->next);
}


int count_node(snake_node* snake, int count){ // подсчёт узлов змеи
    if(snake->next == NULL) return count;
    else return count_node(snake->next, count+1);
}

snake_node* snake; // главная героиня - змея, хранит адрес зада

int move_snake(snake_node* snaked){ // самостоятельное передвижение змейки зависимо от направления
    snake_node* head = get_head(snaked); // голова змеи
    snake_node* tail = get_tail(snaked); // зад змеи
    // изменение направления исходя из нажатой клавиши
    if(last_move == 1){
        if(head->y == 1){ // проверка на то, не уперлась ли змея в стену
            return 1;
        }
        else{
            push_end(snaked, head->x, head->y-1); // создаём новую голову с соответствующими координатами
        }
    }
    else if(last_move == 2){ // аналогично с 1
        if(head->y == Y_MAX-2){
            return 1;
        }
        else{
            push_end(snaked, head->x, head->y+1);
        }
    }
    else if(last_move == 3){ // аналогично с 1
        if(head->x == 1){
            return 1;
        }
        else{
            push_end(snaked, head->x-1, head->y);
        }
    }
    else if(last_move == 4){ // аналогично с 1
        if(head->x == X_MAX-2){
            return 1;
        }
        else{
            push_end(snaked, head->x+1, head->y);
        }
    }
    else{
        return 0;
    }

    for(int i = 0; i < Y_MAX; i++){ // заполнение карты пробелами, яблоком, стенками
        for(int j = 0; j < X_MAX; j++){
            if((apple.x == j) && (apple.y == i)){ // яблоко
                map[i][j] = 'A';
                continue;
            }
            map[i][j]=' '; // пустое место на карте
            if((i == Y_MAX-1) || ( i == 0)) map[i][j]='-'; // верхняя стенка
            else if(( j == X_MAX-1) || (j == 0)) map[i][j] ='|'; // боковая стенка
        }
    }
    if((head->y != apple.y) || (head->x != apple.x)) snake = rm_tail(snake); // если не попали на яблоко, то хвост удаляем -> змея не растёт
    if ((head->y == apple.y) && (head->x == apple.x)){ // обновление координат яблока
        eateen_apple++;
        apple.x = 1 + rand() % (X_MAX-2 - 1);
        apple.y = 1 + rand() % (Y_MAX-2 - 1);
    }
    if(fill_map(snake)){ // заполнение карты змеёй, если змейка замкнулась, то срабатывает
        return 1;
    }


    return 0;
}



void print_snake(snake_node* snake){ // вывод всех узлов змеи
    printf("pre=%p x=%d y=%d adrr=%p next=%p\n",snake->prev, snake->x, snake->y, snake, snake->next);
    if(snake->next == NULL) return;
    else print_snake(snake->next);
}

void free_snake(snake_node* snake){ // освобождение памяти, которую занмает змея
    if(snake->next != NULL) free_snake(snake->next);
    else{
        free(snake);
        return;
    }
}


bool theard2_stop; // флаги потоков
bool theard1_stop;

void* thread_function2(void* arg) {
    int i=0; // счётчик итераций
    while(1) {

        usleep(speed);
        if(move_snake(snake)){ // если змея куда-то уперлась, то конец игры
            theard2_stop = true;
            return NULL;
        }  
        //system("clear");
        for(int i = 0; i < Y_MAX; i++){
           for(int j = 0; j < X_MAX; j++){
                printf("%c",map[i][j]);
            }
            printf("\n");
        }
        i++;
        printf("score: %d     speed %d\n", eateen_apple, speed);
    }
    return NULL;
}

void* thread_function1(void* arg) {
    while(1){
        if(theard2_stop) {
            printf("stoped!\n");
            return NULL;
        }
        usleep(speed);
        move_head = getch();
        if(move_head == 'q') return NULL;
        if((move_head == 'w') && (last_move != 2)){
            //y--;
            if(last_move == 1){
                speed = SPEED_MS/2.35;
            }
            else speed = SPEED_MS;
            last_move=1;
        }
        else if((move_head == 's') && (last_move != 1)){
            //y++;
            if(last_move == 2){
                speed = SPEED_MS/2.35;
            }
            else speed = SPEED_MS;
            last_move=2;
        }
        else if((move_head == 'a') && (last_move != 4)){
            //x--;
            if(last_move == 3){
                speed = SPEED_MS/2/2.325;
            }
            else speed = SPEED_MS/2.325;
            last_move=3;
        }
        else if((move_head == 'd') && (last_move != 3)){
            //x++;
            if(last_move == 4){
                speed = SPEED_MS/2/2.325;
            }
            else speed = SPEED_MS/2.325;
            last_move=4;
        }
   }
     return NULL;
}

int main() {
    apple.x = 50; // первичные координаты яблока
    apple.y = 7;

    last_move = 4; // первичное направление движения

    theard2_stop = false;
    theard1_stop = false;

    snake = create_node(10,10); // создание змеи
    push_end(snake, 10,11);
    push_end(snake, 10,12);
    push_end(snake, 10,13);
    push_end(snake, 10,14);
    push_end(snake, 10,15);
    push_end(snake, 10,16);
    push_end(snake, 10,17);
    push_end(snake, 10,18);
    push_end(snake, 10,19);
    push_end(snake, 10,20);
    push_end(snake, 10,21);
    push_end(snake, 10,22);
    push_end(snake, 10,23);

    pthread_t keyboarding_handler, main_game_cycle; // два потока: для обработки клавиш и для главного движения змеи

    // Создайте и запустите поток обработки клавиш
    if (pthread_create(&keyboarding_handler, NULL, thread_function1, NULL) != 0) {
        perror("pthread_create");
        return 1;
    }

    // Создайте и запустите поток главного цикла
    if (pthread_create(&main_game_cycle, NULL, thread_function2, NULL) != 0) {
        perror("pthread_create");
        return 1;
    }


    // Дождитесь завершения обоих потоков
    pthread_join(keyboarding_handler, NULL);
    pthread_join(main_game_cycle, NULL);
    printf("END GAME\n");
    print_snake(snake);
    printf("%d\n", count_node(snake, 0));
    free_snake(snake);
    return 0;
}
